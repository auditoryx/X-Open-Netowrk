export function middleware() {
  // Temporary empty middleware to satisfy Next.js requirement
}

export const config = {
  matcher: ['/dashboard/:path*'],
};
