'use client';

export default function Notifications() {
  return (
    <div className="mt-8 p-4 bg-yellow-100 text-yellow-800 rounded">
      🔔 You have no new notifications.
    </div>
  );
}
