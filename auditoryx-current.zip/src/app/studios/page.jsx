'use client';
export default function StudiosPage() {
  return (
    <div className="min-h-screen bg-black text-white">
            <div className="flex flex-col items-center justify-center text-center p-8">
        <h1 className="text-4xl font-bold mb-4">Studios</h1>
        <p className="text-gray-400">Book world-class studios around the globe.</p>
      </div>
    </div>
  );
}
