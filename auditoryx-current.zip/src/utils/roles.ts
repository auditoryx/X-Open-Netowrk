export const roles = [
  { label: 'Artist', value: 'artist' },
  { label: 'Producer', value: 'producer' },
  { label: 'Engineer', value: 'engineer' },
  { label: 'Videographer', value: 'videographer' },
  { label: 'Studio', value: 'studio' },
];
