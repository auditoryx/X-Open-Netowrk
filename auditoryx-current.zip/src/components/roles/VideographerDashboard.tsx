'use client'; export default function VideographerDashboard() { return <div className='p-6'>📹 Videographer Dashboard</div>; }
