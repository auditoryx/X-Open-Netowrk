'use client'; export default function StudioDashboard() { return <div className='p-6'>🏙️ Studio Dashboard</div>; }
