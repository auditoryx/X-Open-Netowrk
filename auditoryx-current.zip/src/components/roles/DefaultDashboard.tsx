'use client'; export default function DefaultDashboard() { return <div className='p-6'>👤 Default Dashboard (No role detected)</div>; }
