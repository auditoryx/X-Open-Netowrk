'use client'; export default function ProducerDashboard() { return <div className='p-6'>🎼 Producer Dashboard</div>; }
