'use client'; export default function ArtistDashboard() { return <div className='p-6'>🎤 Artist Dashboard</div>; }
