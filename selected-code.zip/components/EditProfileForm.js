"use client";
import { useState } from "react";

export default function EditProfileForm() {
  const [displayName, setDisplayName] = useState("Zenji");
  const [bio, setBio] = useState("Music visionary. A&R. Creator of vibes.");

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Profile updated!");
    // TODO: hook to backend
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-xl">
      <div>
        <label className="block mb-1">Display Name</label>
        <input
          className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white"
          value={displayName}
          onChange={(e) => setDisplayName(e.target.value)}
        />
      </div>
      <div>
        <label className="block mb-1">Bio</label>
        <textarea
          className="w-full p-2 rounded bg-gray-800 border border-gray-700 text-white"
          value={bio}
          onChange={(e) => setBio(e.target.value)}
        />
      </div>
      <button type="submit" className="btn btn-primary">Save Changes</button>
    </form>
  );
}
