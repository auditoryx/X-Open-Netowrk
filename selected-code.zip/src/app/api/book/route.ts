import { NextRequest, NextResponse } from 'next/server';
import { getFirestore, collection, addDoc, Timestamp } from 'firebase/firestore';
import { initializeApp, getApps, getApp } from 'firebase/app';
import { firebaseConfig } from '@/app/firebase';

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);

export async function POST(req: NextRequest) {
  const { serviceId, message } = await req.json();
  
  await addDoc(collection(db, 'bookingRequests'), {
    serviceId,
    message,
    status: 'pending',
    createdAt: Timestamp.now(),
  });

  return NextResponse.json({ success: true });
}
