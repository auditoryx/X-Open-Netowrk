'use client';
import Navbar from '@/app/components/Navbar';
export default function TestBookingPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      <div className="flex flex-col items-center justify-center text-center p-8">
        <h1 className="text-4xl font-bold mb-4">Test Booking Page</h1>
        <p className="text-gray-400">This is a test page for booking functionality.</p>
      </div>
    </div>
  );
}
